package com.example.petsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class hastaveteriner extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hastaveteriner);
    }
}